#!/bin/bash

declare -i current_time=$(date +%s)
for i in {1..2}
do
	let current_time="$current_time*i"
	echo ${current_time}
done

for i in {1..20}
do
	echo ${i}
done
